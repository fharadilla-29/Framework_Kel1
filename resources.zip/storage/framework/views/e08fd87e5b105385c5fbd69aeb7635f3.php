<div <?php echo e($attributes->class(['fi-dropdown-list p-1'])); ?>>
    <?php echo e($slot); ?>

</div>
<?php /**PATH D:\PemrograanFramework\laragon-6.0-minimal\laragon-6.0-minimal\www\Laravel_Filement\laravel\vendor\filament\support\resources\views/components/dropdown/list/index.blade.php ENDPATH**/ ?>