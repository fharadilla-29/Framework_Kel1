<p
    data-validation-error
    <?php echo e($attributes->class([
            'fi-fo-field-wrp-error-message text-sm text-danger-600 dark:text-danger-400',
        ])); ?>

>
    <?php echo e($slot); ?>

</p>
<?php /**PATH D:\PemrograanFramework\laragon-6.0-minimal\laragon-6.0-minimal\www\Laravel_Filement\laravel\vendor\filament\forms\resources\views/components/field-wrapper/error-message.blade.php ENDPATH**/ ?>